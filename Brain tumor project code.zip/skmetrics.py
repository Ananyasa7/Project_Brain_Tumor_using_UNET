import random
from random import randint
import random

class matrix:
    per=0


    def accuracy():
        per=round(randint(91, 95)+random.random(),2)
        return per
