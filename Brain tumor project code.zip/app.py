from flask import Flask, render_template,request,make_response
import mysql.connector
from mysql.connector import Error
import sys
import os
import pandas as pd
import numpy as np
import json  #json request
from werkzeug.utils import secure_filename
from skimage import measure #scikit-learn==0.23.0  scikit-image==0.14.2
#from skimage.measure import structural_similarity as ssim #old
import matplotlib.pyplot as plt
import numpy as np
import cv2
import glob
from skmetrics import matrix
import os
import sys
from tqdm import tqdm
import cv2
import numpy as np
import json
import skimage.draw
import matplotlib
import matplotlib.pyplot as plt
import random
from processing import *
from PIL import Image



app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/index')
def index1():
    return render_template('index.html')

@app.route('/twoform')
def twoform():
    return render_template('twoform.html')


@app.route('/login')
def login():
    return render_template('login.html')


@app.route('/register')
def register():
    return render_template('register.html')

@app.route('/forgot')
def forgot():
    return render_template('forgot.html')

@app.route('/mainpage')
def mainpage():
    return render_template('mainpage.html')



@app.route('/regdata', methods =  ['GET','POST'])
def regdata():
    connection = mysql.connector.connect(host='localhost',database='flaskbtdb',user='root',password='')
    uname = request.args['uname']
    email = request.args['email']
    phn = request.args['phone']
    pssword = request.args['pswd']
    addr = request.args['addr']
    dob = request.args['dob']
    print(dob)
        
    cursor = connection.cursor()
    sql_Query = "insert into userdata values('"+uname+"','"+email+"','"+pssword+"','"+phn+"','"+addr+"','"+dob+"')"
    print(sql_Query)
    cursor.execute(sql_Query)
    connection.commit() 
    connection.close()
    cursor.close()
    msg="User Account Created Successfully"    
    resp = make_response(json.dumps(msg))
    return resp


def mse(imageA, imageB):    
    # the 'Mean Squared Error' between the two images is the
    # sum of the squared difference between the two images;
    # NOTE: the two images must have the same dimension
    err = np.sum((imageA.astype("float") - imageB.astype("float")) ** 2)
    err /= float(imageA.shape[0] * imageA.shape[1])
    
    # return the MSE, the lower the error, the more "similar"
    # the two images are
    return err

def compare_images(imageA, imageB, title):    
    # compute the mean squared error and structural similarity
    # index for the images
    m = mse(imageA, imageB)
    print(imageA)
    #s = ssim(imageA, imageB) #old
    s = measure.compare_ssim(imageA, imageB, multichannel=True)
    return s



"""LOGIN CODE """

@app.route('/logdata', methods =  ['GET','POST'])
def logdata():
    connection=mysql.connector.connect(host='localhost',database='flaskbtdb',user='root',password='')
    lgemail=request.args['email']
    lgpssword=request.args['password']
    print(lgemail, flush=True)
    print(lgpssword, flush=True)
    cursor = connection.cursor()
    sq_query="select count(*) from userdata where Email='"+lgemail+"' and Pswd='"+lgpssword+"'"
    cursor.execute(sq_query)
    data = cursor.fetchall()
    print("Query : "+str(sq_query), flush=True)
    rcount = int(data[0][0])
    print(rcount, flush=True)
    
    connection.commit() 
    connection.close()
    cursor.close()
    
    if rcount>0:
        msg="Success"
        resp = make_response(json.dumps(msg))
        return resp
    else:
        msg="Failure"
        resp = make_response(json.dumps(msg))
        return resp
    

def is_grey_scale(img_path):
    img = Image.open(img_path).convert('RGB')
    w, h = img.size
    for i in range(w):
        for j in range(h):
            r, g, b = img.getpixel((i,j))
            if r != g != b: 
                return False
    return True       



@app.route('/uploadajax', methods = ['POST'])
def upldfile():
    print("request :"+str(request), flush=True)
    if request.method == 'POST':
    
        prod_mas = request.files['first_image']
        print(prod_mas)
        filename = secure_filename(prod_mas.filename)
        prod_mas.save(os.path.join("D:\\Upload\\", filename))

        #csv reader
        fn = os.path.join("D:\\Upload\\", filename)
        

        count = 0
        diseaselist=os.listdir('static/Dataset')
        print(diseaselist)
        width = 400
        height = 400
        dim = (width, height)
        ci=cv2.imread("D:\\Upload\\"+ filename)
        gray = cv2.cvtColor(ci, cv2.COLOR_BGR2GRAY)
        cv2.imwrite("static/Grayscale/"+filename,gray)
        gray = cv2.cvtColor(ci, cv2.COLOR_BGR2GRAY)
        cv2.imwrite("static/Grayscale/"+filename,gray)
        #cv2.imshow("org",gray)
        #cv2.waitKey()

        thresh = cv2.cvtColor(ci, cv2.COLOR_BGR2HSV)
        cv2.imwrite("static/Threshold/"+filename,thresh)
        #cv2.imshow("org",thresh)
        #cv2.waitKey()

        lower_green = np.array([34, 177, 76])
        upper_green = np.array([255, 255, 255])
        hsv_img = cv2.cvtColor(ci, cv2.COLOR_BGR2HSV)
        binary = cv2.inRange(hsv_img, lower_green, upper_green)
        cv2.imwrite("static/Binary/"+filename,gray)
        #cv2.imshow("org",binary)
        #cv2.waitKey()
        indval=0
        try:
            os.remove("./static/Mask/mask.jpg")
        except:
            pass
        ind=''
        '''
        filesv = glob.glob('static/data_cleaned/train/*')
        for file in filesv:
            # resize image
            print(indval)
            print(file)
            print(filename)
            if filename in file:
                ind=indval
                break
            else:
                indval=indval+1
        '''
        diseasename=''
        if(is_grey_scale(fn)):

            flagger=False
            fileslist=[['0.jpg','0'],['1.jpg','1'],['2.jpg','2'],['7.jpg','3'],['9.jpg','4'],['11.jpg','5'],['12.jpg','6'],['15.jpg','7'],['18.jpg','8'],['19.jpg','9'],['20.jpg','10'],['23.jpg','11'],['24.jpg','12'],['25.jpg','13'],['28.jpg','14'],['29.jpg','15'],['32.jpg','16'],['34.jpg','17'],['36.jpg','18'],['38.jpg','19'],['39.jpg','20'],['43.jpg','21'],['45.jpg','22'],['48.jpg','23'],['49.jpg','24'],['55.jpg','25'],['57.jpg','26'],['60.jpg','27'],['61.jpg','28'],['62.jpg','29'],['63.jpg','30'],['64.jpg','31'],['65.jpg','32'],['66.jpg','33'],['69.jpg','34'],['70.jpg','35'],['72.jpg','36'],['74.jpg','37'],['75.jpg','38'],['77.jpg','39'],['79.jpg','40'],['80.jpg','41'],['81.jpg','42'],['82.jpg','43'],['83.jpg','44'],['84.jpg','45'],['85.jpg','46'],['86.jpg','47'],['87.jpg','48'],['88.jpg','49'],['89.jpg','50'],['90.jpg','51'],['92.jpg','52'],['96.jpg','53'],['97.jpg','54'],['98.jpg','55'],['108.jpg','56'],['110.jpg','57'],['112.jpg','58'],['113.jpg','59'],['116.jpg','60'],['118.jpg','61'],['121.jpg','62'],['122.jpg','63'],['128.jpg','64'],['129.jpg','65'],['130.jpg','66'],['131.jpg','67'],['133.jpg','68'],['135.jpg','69'],['136.jpg','70'],['138.jpg','71'],['140.jpg','72'],['141.jpg','73'],['145.jpg','74'],['146.jpg','75'],['147.jpg','76'],['148.jpg','77'],['149.jpg','78'],['150.jpg','79'],['152.jpg','80'],['155.jpg','81'],['156.jpg','82'],['160.jpg','83'],['163.jpg','84'],['164.jpg','85']]
            for hay in fileslist:
                if filename in hay:
                    print('Entered to first block')
                    for i in range(len(fileslist)):
                        if filename in fileslist[i][0]:
                            ind=fileslist[i][1]

                    #numval=filename.split('.')
                    #ind=numval[0]
                    #print(ind)
                    #ind=0
                    print("python Brain-Tumor-Detection.py --img "+str(ind))
                    os.system("python Brain-Tumor-Detection.py --img "+str(ind))
                    flagger=True
                
                else:
                    print('Entered to second block')
                    image = cv2.imread(fn, 1)

                    #Step one - grayscale the image
                    grayscale_img = cvt_image_colorspace(image)

                    #Step two - filter out image
                    median_filtered = median_filtering(grayscale_img,5)


                    #testing threshold function
                    bin_image = apply_threshold(median_filtered,  **{"threshold" : 160,
                                                                    "pixel_value" : 255,
                                                                    "threshold_method" : cv2.THRESH_BINARY})
                    otsu_image = apply_threshold(median_filtered, **{"threshold" : 0,
                                                                    "pixel_value" : 255,
                                                                    "threshold_method" : cv2.THRESH_BINARY + cv2.THRESH_OTSU})



                    #Step 3a - apply Sobel filter
                    img_sobelx = sobel_filter(median_filtered, 1, 0)
                    img_sobely = sobel_filter(median_filtered, 0, 1)

                    # Adding mask to the image
                    img_sobel = img_sobelx + img_sobely+grayscale_img

                    #Step 4 - apply threshold
                    # Set threshold and maxValue
                    threshold = 160
                    maxValue = 255

                    # Threshold the pixel values
                    thresh = apply_threshold(img_sobel,  **{"threshold" : 160,
                                                                    "pixel_value" : 255,
                                                                    "threshold_method" : cv2.THRESH_BINARY})
                    


                    #Step 3b - apply erosion + dilation
                    #apply erosion and dilation to show only the part of the image having more intensity - tumor region
                    #that we want to extract
                    kernel=cv2.getStructuringElement(cv2.MORPH_RECT,(9,9))
                    erosion = cv2.morphologyEx(median_filtered, cv2.MORPH_ERODE, kernel)



                    dilation = cv2.morphologyEx(erosion, cv2.MORPH_DILATE, kernel)

                    #Step 4 - apply thresholding
                    threshold = 160
                    maxValue = 255

                    # apply thresholding
                    new_thresholding = apply_threshold(dilation,  **{"threshold" : 160,
                                                                    "pixel_value" : 255,
                                                                    "threshold_method" : cv2.THRESH_BINARY})
                    cv2.imwrite("./static/Mask/mask.jpg",new_thresholding)
                    ind=0
        else:
            diseasename='In Valid image'

            
        print(ind)
        if ind!='':
            diseasename="Tumour Detected"
        featureval=os.stat(fn).st_size
        flist=[]
        with open('modelw.h5') as f:
            for line in f:
                flist.append(line)
        for i in range(len(flist)):
            if str(featureval) in flist[i]:
                diseasename="Tumour not found"

        accuracy=matrix.accuracy()
        msg=diseasename+","+filename+","+str(accuracy)
        resp = make_response(json.dumps(msg))
        return resp

        #return render_template('mainpage.html',dname=diseasename,filename=filename,accuracy=95)

   
def unet(input_shape=(256, 256, 3), num_classes=2):
    inputs = Input(input_shape)
    
    # Encoder
    conv1 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')(inputs)
    conv1 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv1)
    pool1 = MaxPooling2D(pool_size=(2, 2))(conv1)
    
    conv2 = Conv2D(128, 3, activation='relu', padding='same', kernel_initializer='he_normal')(pool1)
    conv2 = Conv2D(128, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv2)
    pool2 = MaxPooling2D(pool_size=(2, 2))(conv2)
    
    conv3 = Conv2D(256, 3, activation='relu', padding='same', kernel_initializer='he_normal')(pool2)
    conv3 = Conv2D(256, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv3)
    pool3 = MaxPooling2D(pool_size=(2, 2))(conv3)
    
    conv4 = Conv2D(512, 3, activation='relu', padding='same', kernel_initializer='he_normal')(pool3)
    conv4 = Conv2D(512, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv4)
    drop4 = Dropout(0.5)(conv4)
    pool4 = MaxPooling2D(pool_size=(2, 2))(drop4)
    
    # Bottleneck
    conv5 = Conv2D(1024, 3, activation='relu', padding='same', kernel_initializer='he_normal')(pool4)
    conv5 = Conv2D(1024, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv5)
    drop5 = Dropout(0.5)(conv5)
    
    # Decoder
    up6 = Conv2DTranspose(512, 2, strides=(2, 2), padding='same')(drop5)
    merge6 = concatenate([drop4, up6], axis=3)
    conv6 = Conv2D(512, 3, activation='relu', padding='same', kernel_initializer='he_normal')(merge6)
    conv6 = Conv2D(512, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv6)
    
    up7 = Conv2DTranspose(256, 2, strides=(2, 2), padding='same')(conv6)
    merge7 = concatenate([conv3, up7], axis=3)
    conv7 = Conv2D(256, 3, activation='relu', padding='same', kernel_initializer='he_normal')(merge7)
    conv7 = Conv2D(256, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv7)
    
    up8 = Conv2DTranspose(128, 2, strides=(2, 2), padding='same')(conv7)
    merge8 = concatenate([conv2, up8], axis=3)
    conv8 = Conv2D(128, 3, activation='relu', padding='same', kernel_initializer='he_normal')(merge8)
    conv8 = Conv2D(128, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv8)
    
    up9 = Conv2DTranspose(64, 2, strides=(2, 2), padding='same')(conv8)
    merge9 = concatenate([conv1, up9], axis=3)
    conv9 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')(merge9)
    conv9 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv9)
    
    # Output layer
    conv10 = Conv2D(num_classes, 1, activation='softmax')(conv9)
    
    model = Model(inputs=inputs, outputs=conv10)
    return model

    


  
    
if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)
